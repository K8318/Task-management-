def task():
    task = []  #empty list
    print("---- WELCOME TO THE TASK MANAGEMENT APP ----")

    total_task = int(input("Enter how task you want to add =")) #5
    for i in range(1, total_task+1): 
        task_name = input(f"Enter task {i} = ")
        task.append(task_name)
    
    print(f"Today's task are\n{task}")
    
    while True:
        operation = int(input(" Enter 1add\n2-update\n3-Delete\n5-Exit\Stop/"))
        if operation == 1:
            add = input("Enter task you add want =")
            task.append(add)
            print(f"Task {add} has been successfully added...")

        elif operation == 2:
            updated_val = input("Enter the task name you want to update = ")
            if updated_val in task:
                up = input("Enter new task = ")
                ind = task.index(updated_val)
                task[ind] = up
                print(f"Update task {up}")

        elif operation == 3:
            del_val = input("Which task you want to delete")
            if del_val in tasks:
                ind = tasks.index(del_val)
                print(f"Task {del_val}has been deleted...")
        
        elif operation == 4: 
            print(f"Total tasks = {tasks}")
        
        elif operation == 5:
            print("Closing the program...")
            break

        else:
            print("Invalid Input")

task ()